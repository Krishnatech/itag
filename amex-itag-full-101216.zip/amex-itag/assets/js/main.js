'use strict';

(function ($) {

  // Init Foundation
  $(document).foundation();

  //
  // Homepage new project dropdown inside dropdown
  //
  // Adjust default dropdown behaviour so we can open one inside of another
  // This is coded generically so it will work on any nested dropdown
  $('.dropdown-pane .dropdown.button').on('click', function (e) {
    e.stopPropagation();
    e.preventDefault();
    var thisButton = $(this);
    $('#' + thisButton.data('toggle')).foundation('toggle');
    thisButton.closest('.dropdown-pane').addClass('is-open').attr('aria-hidden', 'false').siblings('.dropdown.button').addClass('hover').attr('aria-expanded', 'true');
  });

  //
  // Homepage project screen shots using Foundation Orbit
  //
  // NOTE: Setup a loop to init all orbit sliders with same options.
  // This is dependent on a specific ID in html
  // These can also be initialized with data attributes in html.
  // See http://foundation.zurb.com/sites/docs/orbit.html
  var orbitOptions = {
    bullets: false,
    autoPlay: false,
    prevClass: 'nav-left',
    nextClass: 'nav-right',
    slideClass: 'screen-shot',
    containerClass: 'screen-shots'
  };
  var screenShots = [];
  // Create new slider for each card
  $('.orbit').each(function (i) {
    screenShots[i] = new Foundation.Orbit($('#screenShots' + (i + 1)), orbitOptions);
  });
  // Update screen number when changed
  $('.orbit').on('slidechange.zf.orbit', function () {
    var thisOrbit = $(this);
    var screenNum = thisOrbit.find('.screen-shot.is-active').data('slide') + 1;
    thisOrbit.find('.screen-current').html(screenNum);
  });

  //
  // Toggle panel content
  //
  // Store all panels in variable
  var panels = $('.panel[data-content]');
  // If there are toggle panels
  if (panels.length > 0) {
    // Attach click handler to change active panel
    panels.on('click', function () {
      var thisPanel = $(this);
      var activePanel = $('.panel.active[data-content]');
      activePanel.removeClass('active');
      $('#' + activePanel.data('content')).removeClass('active');
      thisPanel.addClass('active');
      $('#' + thisPanel.data('content')).addClass('active');
    });
  }

  //
  // Datepicker example on details page
  //
  // For full documentation see http://foundation-datepicker.peterbeno.com/example.html
  $('#dueDateInput').fdatepicker({
    initialDate: '09/15/2016',
    format: 'mm/dd/yyyy'
  });

  //
  // Dropzone for new project screens
  //
  // See http://www.dropzonejs.com/
  if ($('#newProjectScreenDropzone').length > 0) {

    Dropzone.autoDiscover = false;

    var newProjectScreenDropzone = new Dropzone('#newProjectScreenDropzone', {
      clickable: '.dropzone-clickable',
      addRemoveLinks: true,
      thumbnailWidth: 150,
      thumbnailHeight: 150,
      acceptedFiles: '.png, .jpg'
    });

    newProjectScreenDropzone.on('uploadprogress', function (file, progress, bytesSent) {
      file.previewElement.querySelector('.dz-upload').textContent = Math.round(progress) + '%';
    });
  }

  //
  // Add solutions for new project screens
  //
  if ($('.assign-solution-image').length > 0) {

    var assignSolutionClicks = 0;
    $('.assign-solution-image > img').click(function (e) {
      assignSolutionClicks++;
      var thisImage = $(this);
      var offset = thisImage.offset();
      var offsetX = e.pageX - offset.left;
      var offsetY = e.pageY - offset.top;
      var marker = $('<span>', {
        class: 'assign-solution-marker',
        text: assignSolutionClicks,
        style: 'top: ' + offsetY + 'px; left: ' + offsetX + 'px;'
      });
      thisImage.parent().prepend(marker);
      if (assignSolutionClicks === 1) {
        $('#solution1').removeClass('is-hidden');
      }
    });
  }
})(jQuery);